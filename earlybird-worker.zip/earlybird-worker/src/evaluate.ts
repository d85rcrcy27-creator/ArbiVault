import type { VenueQuote, CostBreakdown, EvaluatedOpportunity } from "./types.js";
import { config } from "./config.js";

// Conservative fixed assumptions used only where a venue doesn't give us
// better data. These push toward UNDER-estimating profit (safer to reject
// a good trade than accept a bad one).
const SOLANA_BASE_FEE_LAMPORTS = 5000;
const ESTIMATED_PRIORITY_FEE_LAMPORTS = 10_000; // rough; real value should come from getRecentPrioritizationFees
const DEFAULT_PROTOCOL_FEE_PCT = 0.25; // typical AMM swap fee, applied per leg (2 legs = 0.5% total)
const DEFAULT_PRICE_IMPACT_PCT = 0.3; // used when a venue doesn't report impact

function lamportsToSol(lamports: number): number {
  return lamports / 1_000_000_000;
}

export function evaluateOpportunity(
  buy: VenueQuote,
  sell: VenueQuote,
  solUsdPriceForGas: number
): EvaluatedOpportunity {
  const pair = buy.pair;
  const tradeSize = config.tradeSizeSol;

  // --- staleness check first: don't even trust the prices if they're skewed ---
  const skewMs = Math.abs(buy.fetchedAtMs - sell.fetchedAtMs);
  if (skewMs > config.maxQuoteSkewMs) {
    return rejected(pair, buy, sell, `quotes skewed by ${skewMs}ms (max ${config.maxQuoteSkewMs}ms)`);
  }

  const grossSpread = sell.price - buy.price;
  const spreadPct = (grossSpread / buy.price) * 100;

  if (grossSpread <= 0) {
    return rejected(pair, buy, sell, "no positive spread between venues");
  }

  // --- cost breakdown, computed in quote-currency (e.g. USDC) terms ---
  const gasLamports = SOLANA_BASE_FEE_LAMPORTS + ESTIMATED_PRIORITY_FEE_LAMPORTS;
  const estimatedGas = lamportsToSol(gasLamports) * solUsdPriceForGas;

  const protocolFees = tradeSize * buy.price * (DEFAULT_PROTOCOL_FEE_PCT / 100) * 2; // two legs (buy + sell)

  const buyImpactPct = buy.priceImpactPct ?? DEFAULT_PRICE_IMPACT_PCT;
  const sellImpactPct = sell.priceImpactPct ?? DEFAULT_PRICE_IMPACT_PCT;
  const slippagePct = buyImpactPct + sellImpactPct;
  const slippage = tradeSize * buy.price * (slippagePct / 100);

  const executionCost = estimatedGas + protocolFees + slippage;
  const grossProfit = grossSpread * tradeSize;
  const expectedProfit = grossProfit - executionCost;
  const profitMarginPct = (expectedProfit / (tradeSize * buy.price)) * 100;

  const costs: CostBreakdown = {
    grossSpread,
    estimatedGas,
    protocolFees,
    slippage,
    slippagePct,
    executionCost,
    expectedProfit,
    profitMarginPct,
  };

  // --- safety filter ---
  if (expectedProfit <= 0) {
    return rejected(pair, buy, sell, "expected profit is not positive after costs", costs);
  }
  if (profitMarginPct < config.minProfitMarginPct) {
    return rejected(
      pair,
      buy,
      sell,
      `profit margin ${profitMarginPct.toFixed(3)}% below configured minimum ${config.minProfitMarginPct}%`,
      costs
    );
  }
  if (buyImpactPct > config.maxSlippagePct || sellImpactPct > config.maxSlippagePct) {
    return rejected(
      pair,
      buy,
      sell,
      `estimated slippage exceeds max (${config.maxSlippagePct}%)`,
      costs
    );
  }

  return {
    pair,
    buyVenue: buy.venue,
    sellVenue: sell.venue,
    buyPrice: buy.price,
    sellPrice: sell.price,
    spreadPct,
    costs,
    status: "detected",
    rejectionReason: null,
  };
}

function rejected(
  pair: string,
  buy: VenueQuote,
  sell: VenueQuote,
  reason: string,
  costs?: CostBreakdown
): EvaluatedOpportunity {
  const zero: CostBreakdown = {
    grossSpread: sell.price - buy.price,
    estimatedGas: 0,
    protocolFees: 0,
    slippage: 0,
    slippagePct: 0,
    executionCost: 0,
    expectedProfit: 0,
    profitMarginPct: 0,
  };
  return {
    pair,
    buyVenue: buy.venue,
    sellVenue: sell.venue,
    buyPrice: buy.price,
    sellPrice: sell.price,
    spreadPct: ((sell.price - buy.price) / buy.price) * 100,
    costs: costs ?? zero,
    status: "rejected",
    rejectionReason: reason,
  };
}
