import fetch from "node-fetch";
import type { VenueQuote } from "../types.js";

// Orca's public pricing API. Like Raydium's, this is a simple price lookup
// without per-trade impact data. Endpoint shape changes over time —
// verify against https://docs.orca.so before relying on this in live mode.
const ORCA_PRICE_URL = "https://api.orca.so/v1/token/prices";

const MINTS: Record<string, string> = {
  SOL: "So11111111111111111111111111111111111111112",
  USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
};

export async function fetchOrcaQuote(pair: string): Promise<VenueQuote | null> {
  const [baseSym, quoteSym] = pair.split("/");
  const baseMint = MINTS[baseSym];
  const quoteMint = MINTS[quoteSym];
  if (!baseMint || !quoteMint) {
    console.warn(`[orca] unsupported pair ${pair} — add its mints to MINTS`);
    return null;
  }

  try {
    const res = await fetch(ORCA_PRICE_URL, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) {
      console.warn(`[orca] price request failed: ${res.status}`);
      return null;
    }
    const data = (await res.json()) as any;
    // Response shape assumed as { [mint]: { price: number } } — adjust
    // this extraction if Orca's actual response differs.
    const baseUsd = data?.[baseMint]?.price ?? data?.[baseMint];
    const quoteUsd = data?.[quoteMint]?.price ?? data?.[quoteMint];
    if (!baseUsd || !quoteUsd) {
      console.warn(`[orca] price map missing ${baseSym} or ${quoteSym} — check response shape`);
      return null;
    }

    const price = Number(baseUsd) / Number(quoteUsd);

    return {
      venue: "orca",
      pair,
      price,
      priceImpactPct: null,
      fetchedAtMs: Date.now(),
    };
  } catch (err) {
    console.warn(`[orca] fetch error: ${(err as Error).message}`);
    return null;
  }
}
