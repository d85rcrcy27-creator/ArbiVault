import fetch from "node-fetch";
import type { VenueQuote } from "../types.js";

// Raydium's public price API returns a mint -> USD price map. It doesn't
// give per-trade price impact, so we treat impact as unknown here (null)
// and let the safety filter fall back to a conservative estimate.
// Verify current endpoint against https://docs.raydium.io before live use.
const RAYDIUM_PRICE_URL = "https://api.raydium.io/v2/main/price";

const MINTS: Record<string, string> = {
  SOL: "So11111111111111111111111111111111111111112",
  USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
};

export async function fetchRaydiumQuote(pair: string): Promise<VenueQuote | null> {
  const [baseSym, quoteSym] = pair.split("/");
  const baseMint = MINTS[baseSym];
  const quoteMint = MINTS[quoteSym];
  if (!baseMint || !quoteMint) {
    console.warn(`[raydium] unsupported pair ${pair} — add its mints to MINTS`);
    return null;
  }

  try {
    const res = await fetch(RAYDIUM_PRICE_URL, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) {
      console.warn(`[raydium] price request failed: ${res.status}`);
      return null;
    }
    const data = (await res.json()) as Record<string, number>;
    const baseUsd = data[baseMint];
    const quoteUsd = data[quoteMint];
    if (!baseUsd || !quoteUsd) {
      console.warn(`[raydium] price map missing ${baseSym} or ${quoteSym}`);
      return null;
    }

    const price = baseUsd / quoteUsd; // quote-currency per base unit

    return {
      venue: "raydium",
      pair,
      price,
      priceImpactPct: null,
      fetchedAtMs: Date.now(),
    };
  } catch (err) {
    console.warn(`[raydium] fetch error: ${(err as Error).message}`);
    return null;
  }
}
