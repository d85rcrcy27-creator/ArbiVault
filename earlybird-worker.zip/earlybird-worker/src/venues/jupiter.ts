import fetch from "node-fetch";
import type { VenueQuote } from "./types.js";

// Jupiter's public Quote API. No API key required for basic quoting as of
// this writing, but endpoints/params do change — verify against
// https://station.jup.ag/docs/api before relying on this in live mode.
const JUPITER_QUOTE_URL = "https://quote-api.jup.ag/v6/quote";

const MINTS: Record<string, string> = {
  SOL: "So11111111111111111111111111111111111111112",
  USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
};

export async function fetchJupiterQuote(
  pair: string,
  tradeSizeBase: number
): Promise<VenueQuote | null> {
  const [baseSym, quoteSym] = pair.split("/");
  const inputMint = MINTS[baseSym];
  const outputMint = MINTS[quoteSym];
  if (!inputMint || !outputMint) {
    console.warn(`[jupiter] unsupported pair ${pair} — add its mints to MINTS`);
    return null;
  }

  // SOL has 9 decimals; adjust if you add tokens with different decimals.
  const amountLamports = Math.round(tradeSizeBase * 1_000_000_000);

  const url = `${JUPITER_QUOTE_URL}?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountLamports}&slippageBps=50`;

  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) {
      console.warn(`[jupiter] quote request failed: ${res.status}`);
      return null;
    }
    const data = (await res.json()) as any;

    const outAmount = Number(data.outAmount);
    // USDC has 6 decimals
    const outUi = outAmount / 1_000_000;
    const price = outUi / tradeSizeBase;
    const priceImpactPct = data.priceImpactPct != null ? Number(data.priceImpactPct) * 100 : null;

    return {
      venue: "jupiter",
      pair,
      price,
      priceImpactPct,
      fetchedAtMs: Date.now(),
    };
  } catch (err) {
    console.warn(`[jupiter] fetch error: ${(err as Error).message}`);
    return null;
  }
}
