import { config } from "./config.js";
import { fetchJupiterQuote } from "./venues/jupiter.js";
import { fetchRaydiumQuote } from "./venues/raydium.js";
import { fetchOrcaQuote } from "./venues/orca.js";
import { evaluateOpportunity } from "./evaluate.js";
import { recordOpportunity, closeDb } from "./db.js";
import type { VenueQuote } from "./types.js";

// EarlyBird detection worker.
//
// What this does: polls Jupiter/Raydium/Orca for the configured pair,
// computes full cost-adjusted profitability for every venue pairing, and
// writes BOTH viable and rejected candidates to public.opportunities.
//
// What this NEVER does: hold a private key, sign a transaction, or submit
// anything on-chain. It authenticates to Postgres as `earlybird_worker`,
// a role that can only select/insert on the opportunities table — it is
// not capable of touching wallets, transfers, or trades even if this code
// had a bug. Execution (when you're ready) is a separate, server-side
// Edge Function that re-verifies everything independently, the same
// pattern as the existing sweep-executor.

let shuttingDown = false;

async function fetchAllQuotes(): Promise<VenueQuote[]> {
  const results = await Promise.all([
    fetchJupiterQuote(config.pair, config.tradeSizeSol),
    fetchRaydiumQuote(config.pair),
    fetchOrcaQuote(config.pair),
  ]);
  return results.filter((q): q is VenueQuote => q !== null);
}

async function runCycle(): Promise<void> {
  const quotes = await fetchAllQuotes();

  if (quotes.length < 2) {
    console.log(
      `[cycle] only ${quotes.length}/3 venues responded — need at least 2 to compare, skipping`
    );
    return;
  }

  // Rough SOL/USD price for gas-cost conversion — use whichever quote we
  // have for SOL/USDC; falls back to first quote's price if pair isn't SOL/USDC.
  const solUsdPriceForGas = quotes[0].price;

  let evaluated = 0;
  let viable = 0;

  for (let i = 0; i < quotes.length; i++) {
    for (let j = 0; j < quotes.length; j++) {
      if (i === j) continue;
      const buy = quotes[i];
      const sell = quotes[j];
      const result = evaluateOpportunity(buy, sell, solUsdPriceForGas);
      evaluated++;
      if (result.status === "detected") viable++;

      try {
        await recordOpportunity(result);
      } catch (err) {
        console.error(`[db] failed to record opportunity: ${(err as Error).message}`);
      }
    }
  }

  console.log(
    `[cycle] ${new Date().toISOString()} — evaluated ${evaluated} venue pairs, ${viable} viable (mode=${config.mode})`
  );
}

async function main() {
  console.log(`[earlybird] starting — pair=${config.pair} mode=${config.mode} interval=${config.pollIntervalMs}ms`);
  console.log(`[earlybird] min profit margin=${config.minProfitMarginPct}% trade size=${config.tradeSizeSol} SOL`);

  while (!shuttingDown) {
    try {
      await runCycle();
    } catch (err) {
      console.error(`[cycle] unhandled error: ${(err as Error).message}`);
    }
    await new Promise((resolve) => setTimeout(resolve, config.pollIntervalMs));
  }
}

process.on("SIGINT", async () => {
  console.log("\n[earlybird] shutting down...");
  shuttingDown = true;
  await closeDb();
  process.exit(0);
});

main();
