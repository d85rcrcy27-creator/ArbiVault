export interface VenueQuote {
  venue: "jupiter" | "raydium" | "orca";
  pair: string;
  price: number; // quote-currency per base unit (e.g. USDC per SOL)
  priceImpactPct: number | null; // venue-reported slippage/impact for the trade size, if available
  fetchedAtMs: number;
}

export interface CostBreakdown {
  grossSpread: number; // sell price - buy price, per unit
  estimatedGas: number; // in quote currency (e.g. USDC)
  protocolFees: number; // in quote currency
  slippage: number; // in quote currency
  slippagePct: number; // combined buy+sell price-impact percentage used in the calc
  executionCost: number; // gas + fees + slippage
  expectedProfit: number; // (grossSpread * tradeSize) - executionCost
  profitMarginPct: number; // expectedProfit / (tradeSize * buyPrice) * 100
}

export interface EvaluatedOpportunity {
  pair: string;
  buyVenue: string;
  sellVenue: string;
  buyPrice: number;
  sellPrice: number;
  spreadPct: number;
  costs: CostBreakdown;
  status: "detected" | "rejected";
  rejectionReason: string | null;
}
