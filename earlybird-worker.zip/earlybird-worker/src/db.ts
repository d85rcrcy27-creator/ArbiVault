import pg from "pg";
import { config } from "./config.js";
import type { EvaluatedOpportunity } from "./types.js";

const { Pool } = pg;

// This pool authenticates as the narrowly-scoped `earlybird_worker` Postgres
// role, which can only SELECT/INSERT on public.opportunities. Even if this
// code had a bug, it structurally cannot touch wallets, transfers, trades,
// bot_configs, audit_log, or Vault secrets.
const pool = new Pool({
  host: config.db.host,
  port: config.db.port,
  database: config.db.database,
  user: config.db.user,
  password: config.db.password,
  ssl: { rejectUnauthorized: true },
  max: 3,
});

export async function recordOpportunity(opp: EvaluatedOpportunity): Promise<void> {
  const query = `
    insert into public.opportunities (
      created_by_id, chain, scanner, pair, spread_pct,
      buy_venue, sell_venue, buy_price, sell_price,
      strategy, venue_buy, venue_sell,
      estimated_gas, protocol_fees, slippage_pct, execution_cost,
      expected_profit, profit_margin, mode, status, rejection_reason
    ) values (
      $1, 'solana', 'dex', $2, $3,
      $4, $5, $6, $7,
      'early_bird', $4, $5,
      $8, $9, $10, $11,
      $12, $13, $14, $15, $16
    )
  `;

  const values = [
    config.ownerId,
    opp.pair,
    opp.spreadPct,
    opp.buyVenue,
    opp.sellVenue,
    opp.buyPrice,
    opp.sellPrice,
    opp.costs.estimatedGas,
    opp.costs.protocolFees,
    opp.costs.slippagePct,
    opp.costs.executionCost,
    opp.costs.expectedProfit,
    opp.costs.profitMarginPct,
    config.mode,
    opp.status,
    opp.rejectionReason,
  ];

  await pool.query(query, values);
}

export async function closeDb(): Promise<void> {
  await pool.end();
}
