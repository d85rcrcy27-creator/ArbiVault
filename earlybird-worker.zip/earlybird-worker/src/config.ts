import "dotenv/config";

function required(name: string): string {
  const v = process.env[name];
  if (!v || v.trim() === "") {
    throw new Error(
      `Missing required env var ${name}. Copy .env.example to .env and fill it in.`
    );
  }
  return v;
}

export const config = {
  db: {
    host: required("DB_HOST"),
    port: Number(process.env.DB_PORT ?? "5432"),
    database: required("DB_NAME"),
    user: required("DB_USER"),
    password: required("DB_PASSWORD"),
  },
  solanaRpcUrl: required("SOLANA_RPC_URL"),
  ownerId: required("OWNER_ID"),
  minProfitMarginPct: Number(process.env.MIN_PROFIT_MARGIN_PCT ?? "0.5"),
  pollIntervalMs: Number(process.env.POLL_INTERVAL_MS ?? "30000"),
  pair: process.env.PAIR ?? "SOL/USDC",
  tradeSizeSol: Number(process.env.TRADE_SIZE_SOL ?? "1"),
  maxSlippagePct: Number(process.env.MAX_SLIPPAGE_PCT ?? "1.0"),
  maxQuoteSkewMs: Number(process.env.MAX_QUOTE_SKEW_MS ?? "3000"),
  // mode is intentionally read-only from this worker's perspective: it only
  // ever writes 'simulated' unless you deliberately change it, and even then
  // this worker still never executes anything itself.
  mode: (process.env.MODE === "live" ? "live" : "simulated") as "simulated" | "live",
};

if (config.mode === "live") {
  console.warn(
    "[config] MODE=live — opportunities will be tagged 'live' and become eligible " +
      "for real execution by the separate server-side executor function once you " +
      "enable it there. This worker still does not execute trades itself."
  );
}
