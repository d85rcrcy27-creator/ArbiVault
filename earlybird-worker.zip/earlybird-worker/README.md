# EarlyBird Worker (local, detection-only)

Watches Jupiter / Raydium / Orca for SOL/USDC price discrepancies, computes
full cost-adjusted profitability (gas, protocol fees, slippage), and logs
every candidate — viable or rejected — to `public.opportunities` in your
Arbivault Supabase project.

**This worker never executes a trade.** It has no signing key and its
database credentials (`earlybird_worker`) can only `SELECT`/`INSERT` into
`opportunities` — nothing else. Execution is a deliberately separate,
server-side step (see "Going live" below).

## Setup

```bash
npm install
cp .env.example .env
```

Edit `.env` and fill in:
- `DB_PASSWORD` — the password shown once in chat when the role was created. If you didn't save it, ask to have it rotated (a new `ALTER ROLE ... PASSWORD` — the old one stops working).
- `SOLANA_RPC_URL` — your own RPC endpoint (Helius, QuickNode, etc). No public fallback is used, by design.

## Run

```bash
npm start
```

You should see cycle logs every `POLL_INTERVAL_MS` (default 30s):

```
[cycle] 2026-08-22T... — evaluated 6 venue pairs, 1 viable (mode=simulated)
```

Every candidate — viable and rejected — lands in `opportunities` with
`strategy='early_bird'` and `mode='simulated'`, so you can review what it's
finding before anything changes. Query it directly:

```sql
select pair, buy_venue, sell_venue, profit_margin, status, rejection_reason, detected_at
from opportunities
where strategy = 'early_bird'
order by detected_at desc
limit 20;
```

## Before trusting any of it

The Jupiter/Raydium/Orca endpoints in `src/venues/*.ts` are wired up per
their public docs as of this writing, but DEX APIs change. Before running
for real:

1. Verify each endpoint still matches current docs (links in each file).
2. Let it run in `simulated` mode for a while and sanity-check the numbers in `opportunities` against what you'd expect manually for a few cycles.
3. Only then consider a live execution path (see below) — and even then, start with one trade, capped small, and watch it.

## Going live (not yet built)

This worker intentionally stops at detection. Real execution needs a
separate, server-side Edge Function — same pattern as the existing
`sweep-executor`: signing key pulled from Supabase Vault, independent
re-verification of every number before submitting anything, a hard cap on
trade size, and one transaction at a time to start. That's the next piece
to build once you've watched `simulated` output for long enough to trust
the detection logic — say the word and we'll build it with the same
scrutiny as the sweep function.
