import React, { useState, useEffect, useRef } from 'react';
import { Fingerprint, Shield, Delete, AlertTriangle } from 'lucide-react';
import {
  hashPin,
  authenticateBiometric,
  isBiometricAvailable,
  getSecurityConfig,
  getLockoutState,
  saveLockoutState,
  resetLockoutState,
} from '@/lib/security';

const IDLE_LOCK_MS = 5 * 60 * 1000;
const LOCKOUT_MS = 30 * 60 * 1000;

export default function LockScreen({ onUnlock }) {
  const [stage, setStage] = useState('biometric');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [lockout, setLockout] = useState(getLockoutState());

  useEffect(() => {
    isBiometricAvailable().then(setBiometricAvailable);
  }, []);

  const isLockedOut = lockout.lockedUntil > Date.now();

  async function handleBiometric() {
    if (isLockedOut || scanning) return;
    setScanning(true);
    setError('');
    const success = await authenticateBiometric();
    setScanning(false);
    if (success) {
      setStage('pin');
    } else if (biometricAvailable) {
      setError('Biometric verification failed. Try again or use PIN.');
      setStage('pin');
    } else {
      setStage('pin');
    }
  }

  async function handlePinSubmit() {
    if (pin.length !== 6) return;
    const config = getSecurityConfig();
    if (!config) {
      setError('Security not configured. Complete onboarding first.');
      return;
    }
    const hash = await hashPin(pin);
    if (hash === config.pinHash) {
      resetLockoutState();
      setLockout({ attempts: 0, lockedUntil: 0 });
      setPin('');
      setError('');
      onUnlock();
    } else {
      const newAttempts = lockout.attempts + 1;
      if (newAttempts >= 3) {
        const newLockout = { attempts: 0, lockedUntil: Date.now() + LOCKOUT_MS };
        saveLockoutState(newLockout);
        setLockout(newLockout);
        setError('Too many failed attempts. Vault locked for 30 minutes.');
      } else {
        const newLockout = { ...lockout, attempts: newAttempts };
        saveLockoutState(newLockout);
        setLockout(newLockout);
        setError(`Incorrect PIN. ${3 - newAttempts} attempts remaining.`);
      }
      setPin('');
    }
  }

  function handlePinKey(key) {
    if (key === 'del') {
      setPin(pin.slice(0, -1));
    } else if (pin.length < 6) {
      const newPin = pin + key;
      setPin(newPin);
      if (newPin.length === 6) {
        setTimeout(() => handlePinSubmitWith(newPin), 200);
      }
    }
  }

  async function handlePinSubmitWith(pinVal) {
    const config = getSecurityConfig();
    if (!config) return;
    const hash = await hashPin(pinVal);
    if (hash === config.pinHash) {
      resetLockoutState();
      setPin('');
      onUnlock();
    } else {
      const newAttempts = lockout.attempts + 1;
      if (newAttempts >= 3) {
        const newLockout = { attempts: 0, lockedUntil: Date.now() + LOCKOUT_MS };
        saveLockoutState(newLockout);
        setLockout(newLockout);
        setError('Too many failed attempts. Vault locked for 30 minutes.');
      } else {
        const newLockout = { ...lockout, attempts: newAttempts };
        saveLockoutState(newLockout);
        setLockout(newLockout);
        setError(`Incorrect PIN. ${3 - newAttempts} attempts remaining.`);
      }
      setPin('');
    }
  }

  if (isLockedOut) {
    const remaining = Math.ceil((lockout.lockedUntil - Date.now()) / 60000);
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0A0C10]">
        <div className="text-center fade-in">
          <AlertTriangle className="mx-auto h-16 w-16 text-red-400/60" />
          <h2 className="mt-4 text-xl font-bold text-red-400">Vault Locked</h2>
          <p className="mt-2 text-sm text-slate-500">
            Too many failed attempts. Try again in {remaining} minutes.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0A0C10]">
      <div className="w-full max-w-xs px-6 text-center fade-in">
        <div className="mb-2 flex items-center justify-center gap-2">
          <Shield className="h-6 w-6 text-emerald-400" />
          <span className="text-lg font-bold text-slate-200 tracking-tight">ArbitrexVault</span>
        </div>
        <p className="text-xs text-slate-600 mb-8">Secure access required</p>

        {stage === 'biometric' && biometricAvailable && (
          <>
            <button
              onClick={handleBiometric}
              disabled={scanning}
              className="group relative mx-auto flex h-24 w-24 items-center justify-center rounded-full border-2 border-emerald-500/30 bg-emerald-500/5 transition-all hover:border-emerald-500/60 hover:bg-emerald-500/10 disabled:opacity-50"
            >
              {scanning && (
                <div className="absolute inset-0 rounded-full overflow-hidden">
                  <div className="absolute left-0 right-0 h-0.5 bg-emerald-400 scan-line" style={{ boxShadow: '0 0 8px #00FF88' }} />
                </div>
              )}
              <Fingerprint className={`h-12 w-12 text-emerald-400 ${scanning ? 'finger-pulse' : ''} group-hover:scale-110 transition-transform`} />
            </button>
            <p className="mt-6 text-sm text-slate-400">
              {scanning ? 'Scanning fingerprint…' : 'Tap to scan biometric'}
            </p>
            <button
              onClick={() => setStage('pin')}
              className="mt-3 text-xs text-slate-600 hover:text-slate-400 underline"
            >
              Use PIN instead
            </button>
          </>
        )}

        {stage === 'pin' && (
          <>
            <Fingerprint className="mx-auto h-10 w-10 text-slate-700" />
            <p className="mt-4 text-sm text-slate-400">Enter your 6-digit PIN</p>
            <div className="mt-4 flex justify-center gap-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className={`h-3 w-3 rounded-full transition-all ${i < pin.length ? 'bg-emerald-400 box-glow-green' : 'bg-slate-700'}`}
                />
              ))}
            </div>
            {error && <p className="mt-3 text-xs text-red-400">{error}</p>}
            <div className="mt-6 grid grid-cols-3 gap-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'].map((key, i) => (
                <button
                  key={i}
                  onClick={() => key && handlePinKey(key)}
                  disabled={!key}
                  className="flex h-14 items-center justify-center rounded-xl border border-white/5 bg-[#1C2030] text-lg font-mono font-semibold text-slate-300 transition-all hover:border-emerald-500/30 hover:bg-emerald-500/5 disabled:opacity-0"
                >
                  {key === 'del' ? <Delete className="h-5 w-5" /> : key}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}