export const STRATEGIES = {
  flash_loan: {
    label: 'Flash Loan Arb',
    short: 'Flash Loan',
    color: '#00FF88',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    text: 'text-emerald-400',
    description: 'Borrow via Aave/dYdX, execute arb, repay atomically — zero capital',
    chains: ['bnb', 'solana'],
  },
  flash_swap: {
    label: 'Flash Swap Arb',
    short: 'Flash Swap',
    color: '#2D7FF9',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    text: 'text-blue-400',
    description: 'Pull tokens from Uniswap V3 / PancakeSwap pools, repay in same tx',
    chains: ['bnb', 'solana'],
  },
  mempool_sandwich: {
    label: 'Mempool Sandwich',
    short: 'Mempool',
    color: '#F5A623',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    text: 'text-amber-400',
    description: 'Intercept pending swaps, position ahead of price impact, capture spread',
    chains: ['bnb', 'solana'],
  },
  liquidity_fragmentation: {
    label: 'Liquidity Fragmentation',
    short: 'Fragmentation',
    color: '#9B51E0',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/30',
    text: 'text-purple-400',
    description: 'Exploit sub-optimal router splits across fragmented DEX pools',
    chains: ['solana', 'bnb'],
  },
  cross_chain_latency: {
    label: 'Cross-Chain Latency',
    short: 'Cross-Chain',
    color: '#00D4FF',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/30',
    text: 'text-cyan-400',
    description: 'Exploit price propagation lag between Solana, BNB, and Bitcoin',
    chains: ['solana', 'bnb', 'bitcoin'],
  },
};

export const CHAINS = {
  solana: { label: 'Solana', color: '#9945FF', short: 'SOL', dexes: ['Jupiter', 'Raydium', 'Orca'] },
  bnb: { label: 'BNB Chain', color: '#F0B90B', short: 'BNB', dexes: ['PancakeSwap', 'BiSwap', 'ApeSwap'] },
  bitcoin: { label: 'Bitcoin', color: '#F7931A', short: 'BTC', dexes: ['mempool.space', 'Lightning'] },
};

export const STRATEGY_LIST = Object.entries(STRATEGIES).map(([key, val]) => ({ key, ...val }));
export const CHAIN_LIST = Object.entries(CHAINS).map(([key, val]) => ({ key, ...val }));