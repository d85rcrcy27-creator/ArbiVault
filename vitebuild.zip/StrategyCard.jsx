import React from 'react';
import { Switch } from '@/components/ui/switch';
import { STRATEGIES, CHAINS } from '@/lib/strategies';
import { Activity, Clock, TrendingUp } from 'lucide-react';

export default function StrategyCard({ config, onToggle, onUpdate }) {
  const strat = STRATEGIES[config.strategy];
  if (!strat) return null;

  const chains = strat.chains.map((c) => CHAINS[c]?.short).join(' / ');

  return (
    <div className={`rounded-xl border ${strat.border} ${strat.bg} p-4 fade-in transition-all`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className="h-10 w-1 rounded-full"
            style={{ background: strat.color }}
          />
          <div>
            <h4 className={`text-sm font-semibold ${strat.text}`}>{strat.label}</h4>
            <p className="text-[11px] text-slate-500 mt-0.5 max-w-[280px]">{strat.description}</p>
            <p className="text-[10px] text-slate-600 mt-1 font-mono">{chains}</p>
          </div>
        </div>
        <Switch
          checked={config.enabled}
          onCheckedChange={(v) => onToggle(config.id, v)}
        />
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 border-t border-white/5 pt-3">
        <div>
          <p className="text-[10px] uppercase tracking-wider text-slate-600 flex items-center gap-1">
            <TrendingUp className="h-3 w-3" /> Detected
          </p>
          <p className="font-mono text-sm text-slate-300">{config.opportunities_detected || 0}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-slate-600 flex items-center gap-1">
            <Activity className="h-3 w-3" /> Executed
          </p>
          <p className="font-mono text-sm text-emerald-400">{config.opportunities_executed || 0}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-wider text-slate-600 flex items-center gap-1">
            <Clock className="h-3 w-3" /> Last Scan
          </p>
          <p className="font-mono text-sm text-slate-400">
            {config.last_scan
              ? new Date(config.last_scan).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
              : '—'}
          </p>
        </div>
      </div>

      {config.enabled && (
        <div className="mt-3 grid grid-cols-2 gap-3 border-t border-white/5 pt-3">
          <div>
            <label className="text-[10px] uppercase tracking-wider text-slate-600">Min Profit %</label>
            <input
              type="number"
              step="0.1"
              value={config.min_profit_threshold}
              onChange={(e) => onUpdate(config.id, { min_profit_threshold: parseFloat(e.target.value) })}
              className="mt-1 w-full rounded-md border border-white/10 bg-black/30 px-2 py-1.5 font-mono text-sm text-slate-300 focus:border-emerald-500/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-slate-600">Max Gas</label>
            <input
              type="number"
              step="0.001"
              value={config.max_gas_budget}
              onChange={(e) => onUpdate(config.id, { max_gas_budget: parseFloat(e.target.value) })}
              className="mt-1 w-full rounded-md border border-white/10 bg-black/30 px-2 py-1.5 font-mono text-sm text-slate-300 focus:border-emerald-500/50 focus:outline-none"
            />
          </div>
        </div>
      )}
    </div>
  );
}