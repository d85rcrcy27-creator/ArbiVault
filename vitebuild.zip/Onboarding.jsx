const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { CHAIN_LIST, STRATEGY_LIST } from '@/lib/strategies';
import {
  hashPin,
  registerBiometric,
  isBiometricAvailable,
  saveSecurityConfig,
  getDeviceFingerprint,
} from '@/lib/security';
import { Shield, Fingerprint, Wallet, Check, ArrowRight, ChevronRight } from 'lucide-react';

const STEPS = ['PIN', 'Biometric', 'Wallets', 'Approved', 'Activate'];

export default function Onboarding({ onComplete }) {
  const [step, setStep] = useState(0);
  const [pin, setPin] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [biometricAvail, setBiometricAvail] = useState(null);
  const [biometricRegistered, setBiometricRegistered] = useState(false);
  const [approvedAddresses, setApprovedAddresses] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    isBiometricAvailable().then(setBiometricAvail);
  }, []);

  async function handlePinNext() {
    setError('');
    if (pin.length !== 6) {
      setError('PIN must be 6 digits.');
      return;
    }
    if (pin !== pinConfirm) {
      setError('PINs do not match.');
      return;
    }
    setStep(1);
  }

  async function handleBiometricRegister() {
    setError('');
    setLoading(true);
    const credId = await registerBiometric();
    setLoading(false);
    if (credId) {
      setBiometricRegistered(true);
    } else {
      setError('Biometric registration failed. You can skip and use PIN only.');
    }
  }

  async function handleGenerateWallets() {
    setError('');
    setLoading(true);
    try {
      // Idempotent: check existing wallets & configs — never create duplicates on re-onboarding
      const existingWallets = await db.entities.Wallet.list('-created_date', 50);
      const existingConfigs = await db.entities.BotConfig.list('-created_date', 100);
      for (const chain of CHAIN_LIST) {
        if (!existingWallets.find((w) => w.chain === chain.key)) {
          const address = generateMockAddress(chain.key);
          await db.entities.Wallet.create({
            chain: chain.key,
            address,
            label: `${chain.label} Hot Wallet`,
            balance: 0,
            status: 'active',
          });
        }
      }
      for (const strat of STRATEGY_LIST) {
        for (const chainKey of strat.chains) {
          if (!existingConfigs.find((c) => c.chain === chainKey && c.strategy === strat.key)) {
            await db.entities.BotConfig.create({
              chain: chainKey,
              strategy: strat.key,
              enabled: false,
              min_profit_threshold: 0.5,
              max_gas_budget: 0.01,
              slippage_tolerance: 1.0,
              max_trade_size: 10000,
              opportunities_detected: 0,
              opportunities_executed: 0,
              opportunities_skipped: 0,
            });
          }
        }
      }
      setStep(3);
    } catch (e) {
      setError(e.message || 'Failed to generate wallets.');
    }
    setLoading(false);
  }

  function addApprovedAddress(addr, chain, label) {
    setApprovedAddresses([...approvedAddresses, { address: addr, chain, label, status: 'pending', activation_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() }]);
  }

  async function handleActivate() {
    setError('');
    setLoading(true);
    try {
      const pinHash = await hashPin(pin);
      for (const addr of approvedAddresses) {
        await db.entities.ApprovedWallet.create(addr);
      }
      saveSecurityConfig({
        pinHash,
        biometricRegistered,
        deviceId: getDeviceFingerprint(),
        setupComplete: true,
        createdAt: new Date().toISOString(),
      });
      await db.entities.AuditLog.create({
        event_type: 'auth',
        description: 'Vault initialized — onboarding complete',
        details: JSON.stringify({ biometric: biometricRegistered, device: getDeviceFingerprint() }),
      });
      onComplete();
    } catch (e) {
      setError(e.message || 'Activation failed.');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-[#0A0C10] flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-emerald-500/10 border border-emerald-500/30">
            <Shield className="h-7 w-7 text-emerald-400" />
          </div>
          <h1 className="text-xl font-bold text-slate-100">ArbitrexVault Setup</h1>
          <p className="text-xs text-slate-500 mt-1">Secure your vault in {STEPS.length} steps</p>
        </div>

        <div className="mb-6 flex items-center justify-between">
          {STEPS.map((label, i) => (
            <div key={label} className="flex items-center">
              <div className={`h-7 w-7 flex items-center justify-center rounded-full text-[10px] font-bold ${
                i < step ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                i === step ? 'bg-emerald-500 text-black' :
                'bg-slate-800 text-slate-600 border border-slate-700'
              }`}>
                {i < step ? <Check className="h-3 w-3" /> : i + 1}
              </div>
              {i < STEPS.length - 1 && (
                <div className={`w-8 h-0.5 mx-1 ${i < step ? 'bg-emerald-500/30' : 'bg-slate-800'}`} />
              )}
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-white/5 bg-[#1C2030] p-6 fade-in">
          {step === 0 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Create 6-Digit PIN</h3>
                <p className="text-xs text-slate-500 mt-1">Required to unlock your vault</p>
              </div>
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                placeholder="••••••"
                className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-3 text-center font-mono text-2xl tracking-[0.5em] text-slate-200 focus:border-emerald-500/50 focus:outline-none"
              />
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pinConfirm}
                onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, ''))}
                placeholder="Confirm PIN"
                className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-3 text-center font-mono text-2xl tracking-[0.5em] text-slate-200 focus:border-emerald-500/50 focus:outline-none"
              />
              {error && <p className="text-xs text-red-400">{error}</p>}
              <button
                onClick={handlePinNext}
                className="w-full rounded-lg border border-emerald-500/30 bg-emerald-500/10 py-2.5 text-sm font-semibold text-emerald-400 hover:bg-emerald-500/20"
              >
                Continue <ArrowRight className="inline h-3 w-3 ml-1" />
              </button>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4 text-center">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Biometric Lock</h3>
                <p className="text-xs text-slate-500 mt-1">
                  {biometricAvail === null ? 'Checking…' :
                   biometricAvail ? 'Register your fingerprint or Face ID' :
                   'Biometric not available — PIN-only mode'}
                </p>
              </div>
              {biometricAvail && (
                <button
                  onClick={handleBiometricRegister}
                  disabled={loading || biometricRegistered}
                  className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border-2 border-emerald-500/30 bg-emerald-500/5 hover:border-emerald-500/60 transition-all disabled:opacity-50"
                >
                  {biometricRegistered ? <Check className="h-10 w-10 text-emerald-400" /> : <Fingerprint className="h-10 w-10 text-emerald-400 finger-pulse" />}
                </button>
              )}
              {biometricRegistered && (
                <p className="text-xs text-emerald-400 flex items-center justify-center gap-1">
                  <Check className="h-3 w-3" /> Biometric registered
                </p>
              )}
              {error && <p className="text-xs text-red-400">{error}</p>}
              <button
                onClick={() => setStep(2)}
                className="w-full rounded-lg border border-emerald-500/30 bg-emerald-500/10 py-2.5 text-sm font-semibold text-emerald-400 hover:bg-emerald-500/20"
              >
                {biometricRegistered ? 'Continue' : 'Skip'} <ArrowRight className="inline h-3 w-3 ml-1" />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 text-center">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Generate Hot Wallets</h3>
                <p className="text-xs text-slate-500 mt-1">Create encrypted trading wallets for each chain</p>
              </div>
              <div className="flex justify-center gap-3 py-2">
                {CHAIN_LIST.map((c) => (
                  <div key={c.key} className="flex flex-col items-center gap-1">
                    <div className="h-10 w-10 rounded-lg border border-white/10 bg-black/30 flex items-center justify-center">
                      <Wallet className="h-5 w-5" style={{ color: c.color }} />
                    </div>
                    <span className="text-[10px] text-slate-600">{c.short}</span>
                  </div>
                ))}
              </div>
              {error && <p className="text-xs text-red-400">{error}</p>}
              <button
                onClick={handleGenerateWallets}
                disabled={loading}
                className="w-full rounded-lg border border-emerald-500/30 bg-emerald-500/10 py-2.5 text-sm font-semibold text-emerald-400 hover:bg-emerald-500/20 disabled:opacity-50"
              >
                {loading ? 'Generating…' : 'Generate Wallets'} <ArrowRight className="inline h-3 w-3 ml-1" />
              </button>
            </div>
          )}

          {step === 3 && (
            <ApprovedWalletsStep
              approvedAddresses={approvedAddresses}
              onAdd={addApprovedAddress}
              onNext={() => setStep(4)}
            />
          )}

          {step === 4 && (
            <div className="space-y-4 text-center">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Activate Vault</h3>
                <p className="text-xs text-slate-500 mt-1">Review your configuration and activate</p>
              </div>
              <div className="rounded-lg border border-white/5 bg-black/20 p-3 text-left space-y-1.5 text-xs">
                <div className="flex justify-between"><span className="text-slate-500">PIN</span><span className="text-emerald-400">✓ Set</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Biometric</span><span className={biometricRegistered ? 'text-emerald-400' : 'text-slate-600'}>{biometricRegistered ? '✓ Registered' : 'PIN only'}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Wallets</span><span className="text-emerald-400">{CHAIN_LIST.length} generated</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Approved</span><span className="text-emerald-400">{approvedAddresses.length} addresses</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Strategies</span><span className="text-emerald-400">{STRATEGY_LIST.length} configured</span></div>
              </div>
              {error && <p className="text-xs text-red-400">{error}</p>}
              <button
                onClick={handleActivate}
                disabled={loading}
                className="w-full rounded-lg border border-emerald-500/30 bg-emerald-500/10 py-3 text-sm font-bold text-emerald-400 hover:bg-emerald-500/20 disabled:opacity-50"
              >
                {loading ? 'Activating…' : '🔒 Activate Vault'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ApprovedWalletsStep({ approvedAddresses, onAdd, onNext }) {
  const [addr, setAddr] = useState('');
  const [chain, setChain] = useState('solana');
  const [label, setLabel] = useState('');

  function handleAdd() {
    if (!addr.trim()) return;
    onAdd(addr.trim(), chain, label.trim() || `Wallet ${approvedAddresses.length + 1}`);
    setAddr('');
    setLabel('');
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-slate-200">Approved Withdrawal Wallets</h3>
        <p className="text-xs text-slate-500 mt-1">Funds can only transfer to these addresses (max 3 per chain)</p>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <select value={chain} onChange={(e) => setChain(e.target.value)} className="rounded-lg border border-white/10 bg-black/30 px-2 py-2 text-xs text-slate-300 col-span-1">
          {CHAIN_LIST.map((c) => <option key={c.key} value={c.key}>{c.short}</option>)}
        </select>
        <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Label" className="rounded-lg border border-white/10 bg-black/30 px-2 py-2 text-xs text-slate-300 col-span-2" />
      </div>
      <input value={addr} onChange={(e) => setAddr(e.target.value)} placeholder="Wallet address" className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-2 font-mono text-xs text-slate-300" />
      <button onClick={handleAdd} disabled={!addr.trim()} className="w-full rounded-lg border border-white/10 bg-black/20 py-2 text-xs text-slate-400 hover:text-emerald-400 disabled:opacity-30">
        + Add Address
      </button>
      <div className="space-y-1.5 max-h-32 overflow-y-auto">
        {approvedAddresses.map((a, i) => (
          <div key={i} className="flex items-center gap-2 rounded-lg border border-white/5 bg-black/20 p-2 text-xs">
            <span className="text-slate-500 uppercase">{a.chain}</span>
            <span className="text-slate-400">{a.label}</span>
            <span className="font-mono text-slate-600 truncate ml-auto">{a.address.slice(0, 10)}…</span>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={onNext} className="flex-1 rounded-lg border border-emerald-500/30 bg-emerald-500/10 py-2.5 text-sm font-semibold text-emerald-400 hover:bg-emerald-500/20">
          Continue <ArrowRight className="inline h-3 w-3 ml-1" />
        </button>
      </div>
      <p className="text-[10px] text-slate-600 text-center">You can skip and add wallets later in Wallet Settings</p>
    </div>
  );
}

function generateMockAddress(chain) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const prefix = chain === 'solana' ? '' : chain === 'bnb' ? '0x' : 'bc1q';
  let addr = prefix;
  const len = chain === 'solana' ? 44 : chain === 'bnb' ? 40 : 38;
  for (let i = 0; i < len; i++) addr += chars[Math.floor(Math.random() * chars.length)];
  return addr;
}