import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Bot, ArrowLeftRight, Wallet, Shield, Lock, Scale } from 'lucide-react';

function cn(...classes) {
  return classes.filter(Boolean).join(' ');
}

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/balances', label: 'Balances', icon: Scale },
  { to: '/bot', label: 'Bot Control', icon: Bot },
  { to: '/transfers', label: 'Transfers', icon: ArrowLeftRight },
  { to: '/wallets', label: 'Wallets', icon: Wallet },
];

export default function Sidebar({ onLock }) {
  const location = useLocation();

  return (
    <aside className="fixed left-0 top-0 z-30 flex h-full w-14 flex-col items-center border-r border-white/5 bg-[#0A0C10] py-4 md:w-60 md:items-stretch md:px-3" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <div className="flex items-center gap-2 px-2 mb-6">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 border border-emerald-500/30">
          <Shield className="h-5 w-5 text-emerald-400" />
        </div>
        <div className="hidden md:block">
          <h1 className="text-sm font-bold text-slate-200 tracking-tight">ArbitrexVault</h1>
          <p className="text-[10px] text-slate-600 font-mono">v1.0 · SECURE</p>
        </div>
      </div>

      <nav className="flex flex-col gap-1 flex-1">
        {NAV_ITEMS.map((item) => {
          const active = location.pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                'flex items-center gap-3 rounded-lg px-2 py-3 text-sm transition-all md:px-3',
                active
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'text-slate-500 hover:text-slate-300 hover:bg-white/5 border border-transparent'
              )}
            >
              <item.icon className="h-5 w-5 shrink-0" />
              <span className="hidden md:inline font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <button
        onClick={onLock}
        className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-slate-500 hover:text-red-400 hover:bg-red-500/5 transition-all border border-transparent hover:border-red-500/20"
      >
        <Lock className="h-5 w-5 shrink-0" />
        <span className="hidden md:inline font-medium">Lock Vault</span>
      </button>
    </aside>
  );
}