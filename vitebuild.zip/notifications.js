const notifiedTradeIds = new Set();
const notifiedLogIds = new Set();

export function isNotificationSupported() {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotificationPermission() {
  if (!isNotificationSupported()) return 'unsupported';
  return Notification.permission;
}

export async function requestNotificationPermission() {
  if (!isNotificationSupported()) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  const result = await Notification.requestPermission();
  return result === 'granted';
}

export function showNotification(title, body, options = {}) {
  if (!isNotificationSupported() || Notification.permission !== 'granted') return;
  try {
    const notification = new Notification(title, {
      body,
      icon: '/favicon.ico',
      badge: '/favicon.ico',
      ...options,
    });
    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  } catch { /* ignore */ }
}

export function notifyTradeExecuted(trade) {
  if (!trade || notifiedTradeIds.has(trade.id)) return;
  notifiedTradeIds.add(trade.id);
  const profit = trade.net_profit || 0;
  if (profit > 0) {
    showNotification(
      '💰 Profitable Trade Executed',
      `${trade.pair || 'Pair'} • +$${profit.toFixed(4)} net profit • ${(trade.chain || '').toUpperCase()}`,
      { tag: 'trade-' + trade.id }
    );
  }
}

export function notifyBottleneck(log) {
  if (!log || notifiedLogIds.has(log.id)) return;
  notifiedLogIds.add(log.id);
  const bottleneckTypes = ['bottleneck', 'emergency_stop', 'security_lockout'];
  if (bottleneckTypes.includes(log.event_type)) {
    showNotification(
      '⚠️ Bottleneck Detected',
      log.description || 'A system bottleneck was detected. Check the dashboard for details.',
      { tag: 'bottleneck-' + log.id }
    );
  }
}