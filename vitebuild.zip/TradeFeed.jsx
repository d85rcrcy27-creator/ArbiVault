import React, { useState } from 'react';
import { STRATEGIES, CHAINS } from '@/lib/strategies';
import { ChevronDown, ExternalLink } from 'lucide-react';

function timeAgo(dateStr) {
  if (!dateStr) return '—';
  const diff = Date.now() - new Date(dateStr).getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

export default function TradeFeed({ trades, limit = 50 }) {
  const [expanded, setExpanded] = useState(null);
  const display = (trades || []).slice(0, limit);

  if (!display.length) {
    return (
      <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
        <h3 className="mb-4 text-sm font-semibold text-slate-200">Live Trade Feed</h3>
        <div className="flex h-40 items-center justify-center text-sm text-slate-600">
          Waiting for opportunities…
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-200">Live Trade Feed</h3>
        <span className="flex items-center gap-1.5 text-xs text-slate-500">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />
          Real-time
        </span>
      </div>
      <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
        {display.map((trade) => {
          const strat = STRATEGIES[trade.strategy] || {};
          const chain = CHAINS[trade.chain] || {};
          const isExpanded = expanded === trade.id;
          const isProfit = trade.net_profit >= 0;
          return (
            <div
              key={trade.id}
              className="rounded-lg border border-white/5 bg-black/20 p-3 transition-colors hover:border-white/10 cursor-pointer slide-up"
              onClick={() => setExpanded(isExpanded ? null : trade.id)}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="h-7 w-1 rounded-full shrink-0"
                    style={{ background: strat.color || '#666' }}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-slate-200 truncate">{strat.short || trade.strategy}</span>
                      <span className="text-[10px] text-slate-600">{chain.short || trade.chain}</span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono truncate block">{trade.pair || '—'}</span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span
                    className={`font-mono text-sm font-bold ${isProfit ? 'text-emerald-400 text-glow-green' : 'text-red-400'}`}
                  >
                    {isProfit ? '+' : ''}${(trade.net_profit || 0).toFixed(4)}
                  </span>
                  <p className="text-[10px] text-slate-600">{timeAgo(trade.created_date)}</p>
                </div>
              </div>
              {isExpanded && (
                <div className="mt-2.5 grid grid-cols-2 gap-2 border-t border-white/5 pt-2.5 text-[11px]">
                  <div className="flex justify-between"><span className="text-slate-600">Borrowed</span><span className="font-mono text-slate-400">${(trade.borrowed_amount || 0).toFixed(2)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-600">Gross</span><span className="font-mono text-slate-400">${(trade.gross_profit || 0).toFixed(4)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-600">Fees</span><span className="font-mono text-red-400/70">${(trade.fees_paid || 0).toFixed(4)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-600">Exec ms</span><span className="font-mono text-slate-400">{trade.execution_time_ms || '—'}</span></div>
                  <div className="flex justify-between col-span-2"><span className="text-slate-600">TxID</span><span className="font-mono text-slate-500 truncate max-w-[180px]">{trade.txid || 'pending'}</span></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}