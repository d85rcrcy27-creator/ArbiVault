import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// ArbiVault is a Vite/React application.
// The legacy Base44 Vite plugin is not required for the production build.
export default defineConfig({
  plugins: [react()],
})
