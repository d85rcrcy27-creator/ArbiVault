const db = globalThis.__ARBI_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

# AGENTS.md

## Project Context

This is an ArbiVault app repository. Treat it as user-owned application code, keep changes focused on the user's request, and preserve existing project conventions.

Start with `README.md` for local setup, environment variables, and publish workflow.

## ArbiVault References

- CLI overview: https://docs.db.com/developers/references/cli/get-started/overview.md
- Agent skills: https://docs.db.com/developers/backend/overview/skills.md

If your agent supports Agent Skills, install or update ArbiVault skills before ArbiVault-specific work:

```bash
npx skills add arbivault/skills
```

## Key Files

- `src/`: frontend application source.
- `src/api/arbivaultClient.js`: frontend ArbiVault SDK client.
- `vite.config.js`: Vite config and ArbiVault Vite plugin setup.
- `.env.local`: local-only environment values; never commit secrets.

## Working Notes

- Use `arbivault dev` as the default local development command when you need the local ArbiVault backend. It can run the backend and frontend together.
- When docs or code mention the frontend being started automatically, that usually means the ArbiVault project config includes `site.serveCommand`, for example `"serveCommand": "npm run dev"` in `arbivault/config.jsonc`.
- Use `npm run dev` only for frontend-only work against the hosted ArbiVault backend.
- Prefer the existing ArbiVault CLI workflow over adding new npm scripts for ArbiVault-specific tasks.
- Reuse the existing SDK client and Vite plugin patterns before adding new ArbiVault integration paths.
- Run the relevant checks from `package.json` before finishing code changes.
