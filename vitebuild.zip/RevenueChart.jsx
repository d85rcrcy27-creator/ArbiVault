import React from 'react';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function RevenueChart({ trades }) {
  const data = React.useMemo(() => {
    const sorted = [...trades].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    let cumulative = 0;
    return sorted.map((t) => {
      cumulative += t.net_profit || 0;
      return {
        time: new Date(t.created_date).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        profit: t.net_profit || 0,
        cumulative,
      };
    });
  }, [trades]);

  return (
    <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Cumulative Revenue</h3>
          <p className="text-xs text-slate-500">All-time profit trajectory</p>
        </div>
      </div>
      {data.length === 0 ? (
        <div className="flex h-[260px] items-center justify-center text-sm text-slate-600">
          No trades executed yet
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00FF88" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#00FF88" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="time" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} width={50}
              tickFormatter={(v) => `$${v.toFixed(0)}`} />
            <Tooltip
              contentStyle={{
                background: '#0A0C10',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px',
                fontSize: '12px',
              }}
              labelStyle={{ color: '#94a3b8' }}
              formatter={(v) => [`$${v.toFixed(4)}`, 'Cumulative']}
            />
            <Area
              type="monotone"
              dataKey="cumulative"
              stroke="#00FF88"
              strokeWidth={2}
              fill="url(#revGrad)"
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}