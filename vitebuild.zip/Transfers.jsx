const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { CHAIN_LIST } from '@/lib/strategies';
import { KeyRound, ShieldCheck } from 'lucide-react';

export default function Transfers() {
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    const unsubT = db.entities.Transfer.subscribe(() => loadData());
    return unsubT;
  }, []);

  async function loadData() {
    try {
      setTransfers(await db.entities.Transfer.list('-created_date', 20));
    } catch { /* ignore */ }
    setLoading(false);
  }

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 border-4 border-slate-800 border-t-emerald-400 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-xl font-bold text-slate-100">Transfers</h1>
        <p className="text-sm text-slate-500 mt-1">Withdrawal history & offline signing</p>
      </div>

      <div className="rounded-xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/5 to-transparent p-5 sm:p-6">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-emerald-500/30 bg-emerald-500/10">
            <KeyRound className="h-5 w-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" /> Offline Transaction Signing
            </h3>
            <p className="mt-1 text-xs text-slate-500 leading-relaxed">
              For maximum security, approved destination selection and transaction signing are handled offline. On-chain withdrawal execution will be introduced in a later release.
            </p>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
        <h3 className="text-sm font-semibold text-slate-200 mb-4">Transfer History</h3>
        {transfers.length === 0 ? (
          <div className="flex h-40 items-center justify-center text-sm text-slate-600">No transfers yet</div>
        ) : (
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {transfers.map((t) => (
              <div key={t.id} className="rounded-lg border border-white/5 bg-black/20 p-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm text-emerald-400">{t.amount}</span>
                  <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ${
                    t.status === 'confirmed' ? 'bg-emerald-500/10 text-emerald-400' :
                    t.status === 'pending' ? 'bg-amber-500/10 text-amber-400' :
                    'bg-red-500/10 text-red-400'
                  }`}>{t.status}</span>
                </div>
                <div className="mt-1 flex items-center justify-between text-[10px] text-slate-600 font-mono">
                  <span>{t.to_address.slice(0, 8)}…{t.to_address.slice(-6)}</span>
                  <span className="uppercase">{t.chain}</span>
                </div>
                <p className="mt-0.5 text-[10px] text-slate-700">
                  {new Date(t.created_date).toLocaleString('en-US')}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}