import React, { useState, useEffect, useCallback } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import BotStatusPanel from '@/components/BotStatusPanel';
import LockScreen from '@/components/LockScreen';
import Onboarding from '@/pages/Onboarding';
import { isSetupComplete } from '@/lib/security';

const IDLE_LOCK_MS = 5 * 60 * 1000;

export default function Layout() {
  const [locked, setLocked] = useState(true);
  const [setupComplete, setSetupComplete] = useState(isSetupComplete());
  const idleTimer = React.useRef(null);

  const resetIdleTimer = useCallback(() => {
    if (idleTimer.current) clearTimeout(idleTimer.current);
    if (!locked && setupComplete) {
      idleTimer.current = setTimeout(() => setLocked(true), IDLE_LOCK_MS);
    }
  }, [locked, setupComplete]);

  useEffect(() => {
    if (!setupComplete) return;
    const events = ['mousemove', 'keydown', 'touchstart', 'click'];
    events.forEach((e) => window.addEventListener(e, resetIdleTimer));
    resetIdleTimer();
    return () => {
      events.forEach((e) => window.removeEventListener(e, resetIdleTimer));
      if (idleTimer.current) clearTimeout(idleTimer.current);
    };
  }, [resetIdleTimer, setupComplete]);

  if (!setupComplete) {
    return <Onboarding onComplete={() => setSetupComplete(true)} />;
  }

  if (locked) {
    return <LockScreen onUnlock={() => setLocked(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#0A0C10]">
      <Sidebar onLock={() => setLocked(true)} />
      <main className="pl-16 md:pl-60 md:pr-72" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="mx-auto max-w-6xl p-3 pb-[max(1.5rem,env(safe-area-inset-bottom))] sm:p-4 md:p-6">
          <Outlet />
        </div>
      </main>
      <BotStatusPanel />
    </div>
  );
}