const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef } from 'react';

import { CHAIN_LIST } from '@/lib/strategies';
import { RefreshCw, ArrowUpRight, Scale, Wifi } from 'lucide-react';

const SYNC_INTERVAL_MS = 30 * 1000;
const CHAIN_SYMBOL = { solana: 'SOL', bnb: 'BNB', bitcoin: 'BTC' };

export default function Balances() {
  const [wallets, setWallets] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState(null);
  const syncTimer = useRef(null);

  useEffect(() => {
    loadData();
    syncBalances();
    // Auto-sync on-chain balances every 30s
    syncTimer.current = setInterval(() => syncBalances(), SYNC_INTERVAL_MS);
    // Real-time subscriptions for local data updates
    const unsubW = db.entities.Wallet.subscribe(() => loadData());
    const unsubT = db.entities.Transfer.subscribe(() => loadData());
    return () => {
      clearInterval(syncTimer.current);
      unsubW();
      unsubT();
    };
  }, []);

  async function loadData() {
    try {
      const [w, t] = await Promise.all([
        db.entities.Wallet.list('-updated_date', 50),
        db.entities.Transfer.list('-created_date', 10),
      ]);
      setWallets(w);
      setTransfers(t);
    } catch { /* ignore */ }
    setLoading(false);
  }

  async function syncBalances() {
    setSyncing(true);
    try {
      await db.functions.invoke('syncBalances', {});
      setLastSync(new Date().toISOString());
      await loadData();
    } catch { /* ignore */ }
    setSyncing(false);
  }

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 border-4 border-slate-800 border-t-emerald-400 rounded-full animate-spin" />
      </div>
    );
  }

  const totalBalance = wallets.reduce((s, w) => s + (w.balance || 0), 0);
  const lastSyncLabel = lastSync
    ? new Date(lastSync).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : 'Never';

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-100">Balances</h1>
          <p className="text-sm text-slate-500 mt-1">Real-time hot wallet holdings across all chains</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-[10px] text-slate-600">
            <Wifi className={`h-3 w-3 ${syncing ? 'text-emerald-400 animate-pulse' : 'text-slate-600'}`} />
            {syncing ? 'Syncing…' : `Synced ${lastSyncLabel}`}
          </div>
          <button
            onClick={syncBalances}
            disabled={syncing}
            className="flex items-center gap-2 text-xs text-slate-500 hover:text-slate-300 disabled:opacity-50"
          >
            <RefreshCw className={`h-3 w-3 ${syncing ? 'animate-spin' : ''}`} /> Sync Now
          </button>
        </div>
      </div>

      <div className="rounded-xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 to-transparent p-6 box-glow-green">
        <div className="flex items-center gap-2">
          <Scale className="h-4 w-4 text-emerald-400" />
          <p className="text-[10px] uppercase tracking-wider text-slate-500">Total Vault Balance (USD)</p>
        </div>
        <p className="mt-2 font-mono text-3xl font-bold text-emerald-400 text-glow-green">
          ${totalBalance.toFixed(4)}
        </p>
        <p className="mt-1 text-xs text-slate-600">{wallets.length} hot wallet{wallets.length !== 1 ? 's' : ''} · auto-sync every 30s</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {CHAIN_LIST.map((chain) => {
          const wallet = wallets.find((w) => w.chain === chain.key);
          return (
            <div key={chain.key} className="rounded-xl border border-white/5 bg-[#1C2030] p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: chain.color, boxShadow: `0 0 8px ${chain.color}` }}
                  />
                  <span className="text-sm font-semibold text-slate-200">{chain.label}</span>
                </div>
                {wallet?.status === 'active' && (
                  <span className="text-[9px] text-emerald-400">● ACTIVE</span>
                )}
              </div>
              {wallet ? (
                <>
                  <div className="flex items-baseline gap-1.5">
                    <p className="font-mono text-2xl font-bold text-emerald-400">
                      {(wallet.native_balance || 0).toFixed(6)}
                    </p>
                    <span className="text-xs text-slate-600 font-mono">{CHAIN_SYMBOL[chain.key]}</span>
                  </div>
                  <p className="mt-1 font-mono text-sm text-slate-400">
                    ≈ ${(wallet.balance || 0).toFixed(2)}
                  </p>
                  <p className="mt-2 font-mono text-[10px] text-slate-600 break-all">
                    {wallet.address}
                  </p>
                </>
              ) : (
                <p className="text-sm text-slate-600 py-4">No wallet generated</p>
              )}
            </div>
          );
        })}
      </div>

      <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5">
        <h3 className="text-sm font-semibold text-slate-200 mb-4">Recent Transfers</h3>
        {transfers.length === 0 ? (
          <div className="flex h-20 items-center justify-center text-sm text-slate-600">
            No transfers yet
          </div>
        ) : (
          <div className="space-y-2">
            {transfers.map((t) => {
              const chain = CHAIN_LIST.find((c) => c.key === t.chain);
              return (
                <div key={t.id} className="flex items-center gap-3 rounded-lg border border-white/5 bg-black/20 p-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5">
                    <ArrowUpRight className="h-4 w-4 text-slate-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-slate-300">
                      {t.amount?.toFixed(4)} <span className="text-slate-600">{chain?.label}</span>
                    </p>
                    <p className="font-mono text-[10px] text-slate-600 truncate">
                      → {t.to_address}
                    </p>
                  </div>
                  <span className={`text-[10px] font-medium ${
                    t.status === 'confirmed' ? 'text-emerald-400' :
                    t.status === 'pending' ? 'text-amber-400' : 'text-red-400'
                  }`}>
                    {t.status}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}