const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import StrategyCard from '@/components/StrategyCard';
import { STRATEGY_LIST } from '@/lib/strategies';
import { AlertOctagon, Settings, RefreshCw, Radar } from 'lucide-react';

export default function BotControl() {
  const [configs, setConfigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    loadConfigs();
    const unsub = db.entities.BotConfig.subscribe(() => loadConfigs());
    return unsub;
  }, []);

  async function loadConfigs() {
    try {
      const list = await db.entities.BotConfig.list('-updated_date', 50);
      setConfigs(list);
    } catch { /* ignore */ }
    setLoading(false);
  }

  async function handleToggle(id, enabled) {
    try {
      await db.entities.BotConfig.update(id, { enabled });
      await db.entities.AuditLog.create({
        event_type: enabled ? 'bot_resume' : 'bot_pause',
        description: `Strategy ${enabled ? 'activated' : 'paused'}`,
        details: JSON.stringify({ config_id: id, enabled }),
      });
    } catch { /* ignore */ }
  }

  async function handleUpdate(id, updates) {
    try {
      await db.entities.BotConfig.update(id, updates);
    } catch { /* ignore */ }
  }

  async function handleScanNow() {
    setScanning(true);
    try {
      const chains = [...new Set(configs.map((c) => c.chain))];
      for (const chain of chains) {
        await db.functions.invoke('scanArbitrage', { chain, pair: chain === 'solana' ? 'SOL/USDC' : chain === 'bnb' ? 'BNB/USDT' : 'BTC/USDT' });
      }
      await loadConfigs();
    } catch { /* ignore */ }
    setScanning(false);
  }

  async function handleEmergencyStop() {
    try {
      await db.entities.BotConfig.updateMany(
        { enabled: true },
        { $set: { enabled: false } }
      );
      await db.entities.AuditLog.create({
        event_type: 'emergency_stop',
        description: 'Emergency stop — all strategies halted immediately',
        details: JSON.stringify({ timestamp: new Date().toISOString() }),
      });
    } catch { /* ignore */ }
  }

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 border-4 border-slate-800 border-t-emerald-400 rounded-full animate-spin" />
      </div>
    );
  }

  const activeCount = configs.filter((c) => c.enabled).length;

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-100">Bot Control</h1>
          <p className="text-sm text-slate-500 mt-1">
            {activeCount} of {configs.length} strategies active
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleScanNow}
            disabled={scanning}
            className="flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-2 text-sm font-semibold text-emerald-400 transition-all hover:bg-emerald-500/20 disabled:opacity-50"
          >
            <Radar className={`h-4 w-4 ${scanning ? 'animate-spin' : ''}`} />
            {scanning ? 'Scanning…' : 'Scan Now'}
          </button>
          <button
            onClick={handleEmergencyStop}
            className="flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm font-semibold text-red-400 transition-all hover:bg-red-500/20"
          >
            <AlertOctagon className="h-4 w-4" />
            Emergency Stop
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {configs.map((cfg) => (
          <StrategyCard
            key={cfg.id}
            config={cfg}
            onToggle={handleToggle}
            onUpdate={handleUpdate}
          />
        ))}
        {configs.length === 0 && (
          <div className="col-span-2 rounded-xl border border-white/5 bg-[#1C2030] p-8 text-center">
            <Settings className="mx-auto h-10 w-10 text-slate-700" />
            <p className="mt-3 text-sm text-slate-500">No strategies configured yet.</p>
            <p className="text-xs text-slate-600 mt-1">Complete onboarding to initialize bot strategies.</p>
          </div>
        )}
      </div>

      {configs.length > 0 && (
        <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-200">Bot Health</h3>
            <button
              onClick={loadConfigs}
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300"
            >
              <RefreshCw className="h-3 w-3" /> Refresh
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {configs.map((cfg) => {
              const detected = cfg.opportunities_detected || 0;
              const executed = cfg.opportunities_executed || 0;
              const skipped = cfg.opportunities_skipped || (detected - executed);
              return (
                <div key={cfg.id} className="rounded-lg border border-white/5 bg-black/20 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-slate-600 capitalize truncate">
                    {cfg.strategy.replace(/_/g, ' ')}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">{cfg.chain}</p>
                  <div className="mt-2 space-y-1 text-[11px] font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Detected</span>
                      <span className="text-slate-400">{detected}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Executed</span>
                      <span className="text-emerald-400">{executed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Skipped</span>
                      <span className="text-amber-400">{skipped}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}