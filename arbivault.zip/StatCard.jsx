import React from 'react';

export default function StatCard({ title, value, subtitle, icon: Icon, color = '#00FF88', trend }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-white/5 bg-[#1C2030] p-3.5 sm:p-5 fade-in">
      <div
        className="absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-10 blur-2xl"
        style={{ background: color }}
      />
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[10px] sm:text-xs font-medium uppercase tracking-wider text-slate-500">{title}</p>
          <p
            className="mt-1.5 font-mono text-base sm:text-2xl font-bold tracking-tight"
            style={{ color }}
          >
            {value}
          </p>
        </div>
        {Icon && (
          <div
            className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg shrink-0"
            style={{ background: `${color}15`, color }}
          >
            <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
          </div>
        )}
      </div>
      {subtitle && (
        <div className="mt-3 flex items-center gap-1.5">
          {trend !== undefined && (
            <span className={trend >= 0 ? 'text-emerald-400 text-xs font-mono' : 'text-red-400 text-xs font-mono'}>
              {trend >= 0 ? '↑' : '↓'} {Math.abs(trend)}%
            </span>
          )}
          <span className="text-[11px] sm:text-xs text-slate-500">{subtitle}</span>
        </div>
      )}
    </div>
  );
}