const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { CHAIN_LIST } from '@/lib/strategies';
import { Plus, Trash2, Wallet as WalletIcon, Clock, Check, Lock } from 'lucide-react';
import { encryptAddress, decryptAddress } from '@/lib/crypto';

const COOLDOWN_MS = 24 * 60 * 60 * 1000;

export default function WalletSettings() {
  const [wallets, setWallets] = useState([]);
  const [approved, setApproved] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [newAddr, setNewAddr] = useState('');
  const [newChain, setNewChain] = useState('solana');
  const [newLabel, setNewLabel] = useState('');
  const [error, setError] = useState('');
  const [decryptedAddresses, setDecryptedAddresses] = useState({});

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [w, a] = await Promise.all([
        db.entities.Wallet.list('-created_date', 50),
        db.entities.ApprovedWallet.list('-created_date', 50),
      ]);
      setWallets(w);
      setApproved(a);
      const dec = {};
      for (const aw of a) {
        dec[aw.id] = await decryptAddress(aw.address);
      }
      setDecryptedAddresses(dec);
    } catch { /* ignore */ }
    setLoading(false);
  }

  async function addApprovedWallet() {
    setError('');
    if (!newAddr.trim()) {
      setError('Address is required.');
      return;
    }
    const perChain = approved.filter((a) => a.chain === newChain);
    if (perChain.length >= 3) {
      setError(`Maximum 3 approved wallets per chain. ${newChain.toUpperCase()} already has 3.`);
      return;
    }
    const activationDate = new Date(Date.now() + COOLDOWN_MS).toISOString();
    try {
      const encryptedAddr = await encryptAddress(newAddr.trim());
      await db.entities.ApprovedWallet.create({
        chain: newChain,
        address: encryptedAddr,
        label: newLabel.trim() || `Wallet ${perChain.length + 1}`,
        status: 'pending',
        activation_date: activationDate,
      });
      await db.entities.AuditLog.create({
        event_type: 'wallet_added',
        description: `Approved wallet added: ${newLabel || newAddr.slice(0, 8)}…`,
        details: JSON.stringify({ chain: newChain, address_masked: newAddr.slice(0, 8) + '…' }),
      });
      setNewAddr('');
      setNewLabel('');
      setShowAdd(false);
      loadData();
    } catch (e) {
      setError(e.message || 'Failed to add wallet.');
    }
  }

  async function removeApprovedWallet(id) {
    try {
      await db.entities.ApprovedWallet.delete(id);
      await db.entities.AuditLog.create({
        event_type: 'wallet_removed',
        description: 'Approved wallet removed',
        details: JSON.stringify({ wallet_id: id }),
      });
      loadData();
    } catch { /* ignore */ }
  }

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 border-4 border-slate-800 border-t-emerald-400 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-xl font-bold text-slate-100">Wallet Management</h1>
        <p className="text-sm text-slate-500 mt-1">Hot wallets & approved withdrawal addresses</p>
      </div>

      <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
        <h3 className="text-sm font-semibold text-slate-200 mb-4 flex items-center gap-2">
          <WalletIcon className="h-4 w-4 text-emerald-400" />
          Bot Hot Wallets
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {CHAIN_LIST.map((chain) => {
            const wallet = wallets.find((w) => w.chain === chain.key);
            return (
              <div key={chain.key} className="rounded-lg border border-white/5 bg-black/20 p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="h-2 w-2 rounded-full" style={{ background: chain.color }} />
                  <span className="text-xs font-medium text-slate-300">{chain.label}</span>
                  {wallet?.status === 'active' && (
                    <span className="text-[9px] text-emerald-400 ml-auto">● ACTIVE</span>
                  )}
                </div>
                {wallet ? (
                  <>
                    <p className="font-mono text-[11px] text-slate-400 break-all">{wallet.address}</p>
                    <p className="mt-2 font-mono text-sm text-emerald-400">
                      {wallet.balance?.toFixed(4) || '0.0000'}
                    </p>
                  </>
                ) : (
                  <p className="text-xs text-slate-600 py-2">Not generated</p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="rounded-xl border border-white/5 bg-[#1C2030] p-5 fade-in">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-1.5">
            <Lock className="h-3.5 w-3.5 text-emerald-400" /> Approved Withdrawal Wallets
          </h3>
          <button
            onClick={() => setShowAdd(!showAdd)}
            className="flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300"
          >
            <Plus className="h-3 w-3" /> Add Wallet
          </button>
        </div>

        {showAdd && (
          <div className="mb-4 rounded-lg border border-white/5 bg-black/20 p-4 space-y-3 slide-up">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="text-[10px] uppercase tracking-wider text-slate-600">Chain</label>
                <select
                  value={newChain}
                  onChange={(e) => setNewChain(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 px-2 py-1.5 text-sm text-slate-300"
                >
                  {CHAIN_LIST.map((c) => (
                    <option key={c.key} value={c.key}>{c.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-slate-600">Label</label>
                <input
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="My Ledger"
                  className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 px-2 py-1.5 text-sm text-slate-300"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wider text-slate-600">Address</label>
                <input
                  value={newAddr}
                  onChange={(e) => setNewAddr(e.target.value)}
                  placeholder="0x… / bc1… / …"
                  className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 px-2 py-1.5 font-mono text-xs text-slate-300"
                />
              </div>
            </div>
            {error && <p className="text-xs text-red-400">{error}</p>}
            <p className="text-[10px] text-amber-400/70 flex items-center gap-1">
              <Clock className="h-3 w-3" /> New wallets are locked for 24 hours before activation
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => { setShowAdd(false); setError(''); }}
                className="rounded-lg border border-white/10 px-4 py-1.5 text-xs text-slate-400"
              >
                Cancel
              </button>
              <button
                onClick={addApprovedWallet}
                className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-1.5 text-xs font-semibold text-emerald-400"
              >
                Add Wallet
              </button>
            </div>
          </div>
        )}

        <div className="space-y-2">
          {approved.map((w) => {
            const chain = CHAIN_LIST.find((c) => c.key === w.chain);
            const isActive = w.status === 'active';
            const timeUntilActive = w.activation_date ? new Date(w.activation_date).getTime() - Date.now() : 0;
            const hoursLeft = Math.max(0, Math.ceil(timeUntilActive / (60 * 60 * 1000)));
            return (
              <div key={w.id} className="flex items-center gap-3 rounded-lg border border-white/5 bg-black/20 p-3">
                <span className="h-2 w-2 rounded-full shrink-0" style={{ background: chain?.color }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-slate-300">{w.label}</span>
                    {isActive ? (
                      <span className="flex items-center gap-0.5 text-[9px] text-emerald-400"><Check className="h-2.5 w-2.5" /> ACTIVE</span>
                    ) : (
                      <span className="flex items-center gap-0.5 text-[9px] text-amber-400"><Clock className="h-2.5 w-2.5" /> {hoursLeft}h left</span>
                    )}
                  </div>
                  <p className="font-mono text-[11px] text-slate-500 truncate">{decryptedAddresses[w.id] || '•••• Decrypting'}</p>
                </div>
                <button
                  onClick={() => removeApprovedWallet(w.id)}
                  className="text-slate-600 hover:text-red-400 transition-colors shrink-0"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            );
          })}
          {approved.length === 0 && (
            <div className="flex h-24 items-center justify-center text-sm text-slate-600">
              No approved wallets yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
}