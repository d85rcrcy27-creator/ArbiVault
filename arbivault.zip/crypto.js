// Client-side AES-GCM encryption for sensitive wallet addresses.
// Key is generated once and stored as JWK in localStorage (never sent to server).
// Addresses are encrypted before storing in entities; decrypted only in the browser.

const KEY_STORAGE = 'arbitrexvault_enc_key_v1';

async function getKey() {
  let jwk = localStorage.getItem(KEY_STORAGE);
  if (!jwk) {
    const key = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    jwk = JSON.stringify(await crypto.subtle.exportKey('jwk', key));
    localStorage.setItem(KEY_STORAGE, jwk);
  }
  return crypto.subtle.importKey('jwk', JSON.parse(jwk), { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

export async function encryptAddress(plaintext) {
  if (!plaintext) return plaintext;
  const key = await getKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded);
  const combined = new Uint8Array(iv.length + ciphertext.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(ciphertext), iv.length);
  return btoa(String.fromCharCode(...combined));
}

export async function decryptAddress(ciphertext) {
  if (!ciphertext) return ciphertext;
  try {
    const key = await getKey();
    const combined = Uint8Array.from(atob(ciphertext), (c) => c.charCodeAt(0));
    const iv = combined.slice(0, 12);
    const data = combined.slice(12);
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
    return new TextDecoder().decode(decrypted);
  } catch {
    // Decryption failed — likely legacy plaintext record, return as-is
    return ciphertext;
  }
}