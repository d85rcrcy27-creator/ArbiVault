const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import StatCard from '@/components/StatCard';
import RevenueChart from '@/components/RevenueChart';
import TradeFeed from '@/components/TradeFeed';
import { DollarSign, TrendingUp, Activity, Target, Bot, Zap } from 'lucide-react';

export default function Dashboard() {
  const [trades, setTrades] = useState([]);
  const [configs, setConfigs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    const unsubTrades = db.entities.Trade.subscribe((event) => {
      if (event.type === 'create') {
        setTrades((prev) => [event.data, ...prev].slice(0, 50));
      }
    });
    const unsubConfigs = db.entities.BotConfig.subscribe(() => loadConfigs());
    return () => { unsubTrades(); unsubConfigs(); };
  }, []);

  async function loadConfigs() {
    try {
      setConfigs(await db.entities.BotConfig.list('-updated_date', 50));
    } catch { /* ignore */ }
  }

  async function loadData() {
    try {
      const [tradeList, configList] = await Promise.all([
        db.entities.Trade.list('-created_date', 50),
        db.entities.BotConfig.list('-updated_date', 50),
      ]);
      setTrades(tradeList);
      setConfigs(configList);
    } catch { /* ignore */ }
    setLoading(false);
  }

  const totalRevenue = trades.reduce((s, t) => s + (t.net_profit || 0), 0);
  const todayTrades = trades.filter((t) => {
    const d = new Date(t.created_date);
    const now = new Date();
    return d.toDateString() === now.toDateString();
  });
  const todayRevenue = todayTrades.reduce((s, t) => s + (t.net_profit || 0), 0);
  const activeStrategies = configs.filter((c) => c.enabled).length;
  const executedCount = configs.reduce((s, c) => s + (c.opportunities_executed || 0), 0);
  const detectedCount = configs.reduce((s, c) => s + (c.opportunities_detected || 0), 0);
  const winRate = detectedCount > 0 ? ((executedCount / detectedCount) * 100).toFixed(1) : '0.0';

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <div className="h-8 w-8 border-4 border-slate-800 border-t-emerald-400 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6 fade-in">
      <div>
        <h1 className="text-lg sm:text-xl font-bold text-slate-100">Command Center</h1>
        <p className="text-sm text-slate-500 mt-1">Real-time revenue monitoring across all chains</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        <StatCard
          title="Total Revenue"
          value={`$${totalRevenue.toFixed(4)}`}
          subtitle="All-time net profit"
          icon={DollarSign}
          color="#00FF88"
        />
        <StatCard
          title="Today"
          value={`$${todayRevenue.toFixed(4)}`}
          subtitle={`${todayTrades.length} trades today`}
          icon={TrendingUp}
          color="#2D7FF9"
        />
        <StatCard
          title="Win Rate"
          value={`${winRate}%`}
          subtitle={`${executedCount} / ${detectedCount} opportunities`}
          icon={Target}
          color="#9B51E0"
        />
        <StatCard
          title="Active Bots"
          value={activeStrategies}
          subtitle={`${configs.length} strategies configured`}
          icon={Bot}
          color="#F5A623"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <RevenueChart trades={trades} />
        <TradeFeed trades={trades} limit={20} />
      </div>

      <div className="rounded-xl border border-white/5 bg-[#1C2030] p-4 sm:p-5 fade-in">
        <h3 className="text-sm font-semibold text-slate-200 mb-4">Strategy Performance</h3>
        <div className="space-y-2">
          {configs.map((cfg) => {
            const stratColor = cfg.strategy === 'flash_loan' ? '#00FF88'
              : cfg.strategy === 'flash_swap' ? '#2D7FF9'
              : cfg.strategy === 'mempool_sandwich' ? '#F5A623'
              : cfg.strategy === 'liquidity_fragmentation' ? '#9B51E0'
              : '#00D4FF';
            const detected = cfg.opportunities_detected || 0;
            const executed = cfg.opportunities_executed || 0;
            const pct = detected > 0 ? (executed / detected) * 100 : 0;
            return (
              <div key={cfg.id} className="flex items-center gap-3">
                <span className="text-xs text-slate-400 w-20 sm:w-24 capitalize truncate md:w-32">
                  {cfg.strategy.replace(/_/g, ' ')}
                </span>
                <div className="flex-1 min-w-0 h-2 rounded-full bg-black/30 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${pct}%`, background: stratColor }}
                  />
                </div>
                <span className="font-mono text-[11px] text-slate-500 w-12 text-right sm:w-14 md:w-20">
                  {executed}/{detected}
                </span>
              </div>
            );
          })}
          {configs.length === 0 && (
            <p className="text-sm text-slate-600 py-4 text-center">
              No strategies configured. Visit Bot Control to set up.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}