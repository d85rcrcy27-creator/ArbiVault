const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef } from 'react';

import { CHAIN_LIST } from '@/lib/strategies';
import { X, Zap, AlertOctagon } from 'lucide-react';
import { requestNotificationPermission, notifyTradeExecuted, notifyBottleneck } from '@/lib/notifications';

export default function BotStatusPanel({ onEmergencyStop }) {
  const [configs, setConfigs] = useState([]);
  const [collapsed, setCollapsed] = useState(() =>
    typeof window !== 'undefined' && window.innerWidth < 768
  );
  const [stopping, setStopping] = useState(false);

  const [autoScanning, setAutoScanning] = useState(false);
  const lastTradeCount = useRef(0);

  useEffect(() => {
    requestNotificationPermission();
    loadConfigs();
    const unsub = db.entities.BotConfig.subscribe(() => loadConfigs());

    // Subscribe to new trades → browser push notification on profitable execution
    const unsubTrades = db.entities.Trade.subscribe((event) => {
      if (event.type === 'create' && event.data) {
        notifyTradeExecuted(event.data);
      }
    });

    // Subscribe to audit logs → browser push notification on bottlenecks
    const unsubLogs = db.entities.AuditLog.subscribe((event) => {
      if (event.type === 'create' && event.data) {
        notifyBottleneck(event.data);
      }
    });

    return () => { unsub(); unsubTrades(); unsubLogs(); };
  }, []);

  // Autonomous scanning loop — fires every 45s when any strategy is active
  useEffect(() => {
    const hasActive = configs.some((c) => c.enabled);
    if (!hasActive) return;
    setAutoScanning(true);
    const interval = setInterval(async () => {
      const activeChains = [...new Set(configs.filter((c) => c.enabled).map((c) => c.chain))];
      for (const chain of activeChains) {
        try {
          await db.functions.invoke('scanArbitrage', {
            chain,
            pair: chain === 'solana' ? 'SOL/USDC' : chain === 'bnb' ? 'BNB/USDT' : 'BTC/USDT',
          });
          // DEX-focused scan (Solana/BNB only — Bitcoin has no DEX layer)
          if (chain === 'solana' || chain === 'bnb') {
            try {
              await db.functions.invoke('scanDexOpportunities', { chain });
            } catch { /* ignore DEX scan errors */ }
          }
        } catch { /* ignore scan errors */ }
      }
      loadConfigs();
    }, 45000);
    return () => { clearInterval(interval); setAutoScanning(false); };
  }, [configs]);

  async function loadConfigs() {
    try {
      const list = await db.entities.BotConfig.list('-updated_date', 50);
      setConfigs(list);
    } catch { /* ignore */ }
  }

  async function handleEmergencyStop() {
    setStopping(true);
    try {
      await db.entities.BotConfig.updateMany(
        { enabled: true },
        { $set: { enabled: false } }
      );
      await db.entities.AuditLog.create({
        event_type: 'emergency_stop',
        description: 'Global emergency stop triggered — all strategies halted',
        details: JSON.stringify({ timestamp: new Date().toISOString() }),
      });
      if (onEmergencyStop) onEmergencyStop();
    } catch { /* ignore */ }
    setStopping(false);
  }

  const activeCount = configs.filter((c) => c.enabled).length;
  const totalDetected = configs.reduce((s, c) => s + (c.opportunities_detected || 0), 0);
  const totalExecuted = configs.reduce((s, c) => s + (c.opportunities_executed || 0), 0);

  if (collapsed) {
    return (
      <button
        onClick={() => setCollapsed(false)}
        className="fixed right-3 top-20 z-30 flex h-10 w-10 items-center justify-center rounded-lg border border-emerald-500/30 bg-[#1C2030] text-emerald-400 shadow-lg"
      >
        <Zap className="h-5 w-5" />
      </button>
    );
  }

  return (
    <aside className="fixed right-0 top-0 z-30 flex h-full w-72 flex-col border-l border-white/5 bg-[#0A0C10] p-4 fade-in">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Bot Status</h3>
          <p className="text-[11px] text-slate-600 flex items-center gap-1">
            {autoScanning && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 pulse-dot" />}
            {autoScanning ? 'Auto-scanning' : 'Live monitoring'}
          </p>
        </div>
        <button onClick={() => setCollapsed(true)} className="text-slate-600 hover:text-slate-400">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-4">
        <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
          <p className="text-[10px] uppercase tracking-wider text-slate-600">Active</p>
          <p className="font-mono text-lg font-bold text-emerald-400">{activeCount}</p>
        </div>
        <div className="rounded-lg border border-white/5 bg-black/20 p-3">
          <p className="text-[10px] uppercase tracking-wider text-slate-600">Win Rate</p>
          <p className="font-mono text-lg font-bold text-slate-300">
            {totalDetected > 0 ? ((totalExecuted / totalDetected) * 100).toFixed(1) : '0.0'}%
          </p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {configs.map((cfg) => {
          const chain = CHAIN_LIST.find((c) => c.key === cfg.chain);
          if (!chain) return null;
          return (
            <div
              key={cfg.id}
              className={`rounded-lg border p-2.5 ${cfg.enabled ? 'border-emerald-500/20 bg-emerald-500/5' : 'border-white/5 bg-black/20'}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className={`h-2 w-2 rounded-full ${cfg.enabled ? 'bg-emerald-400 pulse-dot' : 'bg-slate-700'}`}
                    style={cfg.enabled ? { boxShadow: `0 0 8px ${chain.color}` } : {}}
                  />
                  <span className="text-xs font-medium text-slate-300">{chain.label}</span>
                </div>
                <span className="text-[10px] text-slate-600 capitalize">{cfg.strategy.replace(/_/g, ' ')}</span>
              </div>
              <div className="mt-1.5 flex justify-between text-[10px] text-slate-600 font-mono">
                <span>Det: {cfg.opportunities_detected || 0}</span>
                <span>Exe: {cfg.opportunities_executed || 0}</span>
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={handleEmergencyStop}
        disabled={stopping}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 py-2.5 text-sm font-semibold text-red-400 transition-all hover:bg-red-500/20 disabled:opacity-50"
      >
        <AlertOctagon className="h-4 w-4" />
        {stopping ? 'Stopping…' : 'Emergency Stop'}
      </button>
    </aside>
  );
}